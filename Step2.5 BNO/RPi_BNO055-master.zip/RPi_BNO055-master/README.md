# RPi_BNO055
BNO055 IMU Library for Raspberry Pi based on the Adafruit libraries for Arduino.
